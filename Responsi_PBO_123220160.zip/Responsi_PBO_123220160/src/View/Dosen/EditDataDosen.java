/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View.Dosen;

import Controller.ControllerDosen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import Model.Dosen.ModelDosen;

/**
 *
 * @author Lab Informatika
 */
public class EditDataDosen extends JFrame{
    ControllerDosen controller;
    
    JLabel header = new JLabel("Edit Dosen");
    JLabel labelInputId = new JLabel("Id");
    JLabel labelInputNama = new JLabel("Nama");
    JLabel labelInputNumber = new JLabel("No_Hp");
    JLabel labelInputEmail = new JLabel("Email");
    JTextField inputId = new JTextField();
    JTextField inputNama = new JTextField();
    JTextField inputNumber = new JTextField();
    JTextField inputEmail = new JTextField();
    JButton tombolEdit = new JButton("Edit Dosen");
    JButton tombolKembali = new JButton("Kembali");

    public EditDataDosen(ModelDosen dosen) {
        setTitle("Edit Dosen");
        setVisible(true);
        setSize(480, 260);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        add(header);
        add(labelInputId);
        add(labelInputNama);
        add(labelInputNumber);
        add(labelInputEmail);
        add(inputId);
        add(inputNama);
        add(inputNumber);
        add(inputEmail);
        add(tombolEdit);
        add(tombolKembali);

        header.setBounds(20, 8, 440, 24);
        labelInputNama.setBounds(20, 32, 440, 24);
        inputNama.setBounds(18, 56, 440, 36);
        labelInputNumber.setBounds(20, 96, 440, 24);
        inputNumber.setBounds(18, 120, 440, 36);
        tombolKembali.setBounds(20, 160, 215, 40);
        tombolEdit.setBounds(240, 160, 215, 40);
        
        inputNama.setText(dosen.getName());
        inputNumber.setText(dosen.getNumber());
        
        controller = new ControllerDosen(this);

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewDataDosen();
            }
        });

        tombolEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.editDosen(dosen.getId());
            }
        });
    }
    
    public String getInputNama() {
        return inputNama.getText();
    }
    
    public String getInputNIDN() {
        return inputNumber.getText();
    }
}
