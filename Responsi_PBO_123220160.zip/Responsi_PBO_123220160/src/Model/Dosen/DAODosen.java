/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Dosen;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Lab Informatika
 */
public class DAODosen implements InterfaceDAODosen{
    @Override
    public void insert(ModelDosen dosen) {
        try {
            String query = "INSERT INTO dosen (id, nama, no_hp, email) VALUES (?, ?);";
            
            PreparedStatement preparedStatement;
            preparedStatement = Connector.connect().prepareStatement(query);
            preparedStatement.setInt(1, dosen.getId());
            preparedStatement.setString(2, dosen.getName());
            preparedStatement.setString(3, dosen.getNumber());
            preparedStatement.setString(4, dosen.getEmail());
            
            preparedStatement.executeUpdate();
            
            preparedStatement.close();
        } catch (SQLException e) {
            System.out.println("Input Gagal: " + e.getLocalizedMessage());
        } 
    }

    @Override
    public void update(ModelDosen dosen) {
        try {
            String query = "UPDATE dosen SET id=?, nama=?, no_hp=?, email=? WHERE id=?;";
            
            PreparedStatement preparedStatement;
            preparedStatement = Connector.connect().prepareStatement(query);
            preparedStatement.setInt(1, dosen.getId());
            preparedStatement.setString(2, dosen.getName());
            preparedStatement.setString(3, dosen.getNumber());
            preparedStatement.setString(4, dosen.getEmail());
            
            preparedStatement.executeUpdate();
           
            preparedStatement.close();
        } catch (SQLException e) {
            System.out.println("Update gagal: " + e.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            String query = "DELETE FROM dosen WHERE id=?;";
            
            PreparedStatement preparedStatement;
            preparedStatement = Connector.connect().prepareStatement(query);
            preparedStatement.setInt(1, id);
            
            preparedStatement.executeUpdate();
            
            preparedStatement.close();
        } catch (SQLException e) {
            System.out.println("Delete gagal: " + e.getLocalizedMessage());
        }
    }

    @Override
    public List<ModelDosen> getAll() {
        List<ModelDosen> dosenList = new ArrayList<>();

        try {
            Statement statement = Connector.connect().createStatement();
            
            String query = "SELECT * FROM dosen;";
            
            ResultSet resultSet = statement.executeQuery(query);
            
            while (resultSet.next()) {
                ModelDosen dosen = new ModelDosen();
                
                dosen.setId(resultSet.getInt("id"));
                dosen.setName(resultSet.getString("nama"));
                dosen.setNumber(resultSet.getString("no_hp"));
                dosen.setEmail(resultSet.getString("email"));
                
                dosenList.add(dosen);
            }
            
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return dosenList;
    }
}
