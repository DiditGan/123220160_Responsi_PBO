/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Dosen.*;
import View.Dosen.*;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Lab Informatika
 */
public class ControllerDosen {
    ViewDataDosen viewTableDosen;
    InputDataDosen viewInputDosen;
    EditDataDosen viewEditDosen;

    InterfaceDAODosen daoDosenImpl;

    List<ModelDosen> listDosen;
 
    public ControllerDosen(ViewDataDosen viewTableDosen) {
        this.viewTableDosen = viewTableDosen;
        this.daoDosenImpl = new DAODosen();
    }
    
    public ControllerDosen(InputDataDosen viewInputDosen) {
        this.viewInputDosen = viewInputDosen;
        this.daoDosenImpl = new DAODosen();
    }
    
    public ControllerDosen(EditDataDosen viewEditDosen) {
        this.viewEditDosen = viewEditDosen;
        this.daoDosenImpl = new DAODosen();
    }

    public void showAllDosen() {
        listDosen = daoDosenImpl.getAll();

        ModelTableDosen table = new ModelTableDosen(listDosen);

        viewTableDosen.getTableDosen().setModel(table);
    }

    public void insertDosen() {
        try {
            ModelDosen dosenBaru = new ModelDosen();
            
            Integer id = viewInputDosen.getInputId();
            String name = viewInputDosen.getInputNama();
            String no_hp = viewInputDosen.getInputNumber();
            String email = viewInputDosen.getInputEmail();

            if ("".equals(id) || "".equals(name) || "".equals(no_hp) || "".equals(email)) {
                throw new Exception("Tidak boleh kosong!");
            }
            
            dosenBaru.setId(id);
            dosenBaru.setName(name);
            dosenBaru.setNumber(no_hp);
            dosenBaru.setEmail(email);
            
            daoDosenImpl.insert(dosenBaru);
            
            JOptionPane.showMessageDialog(null, "Dosen baru berhasil ditambahkan");
            
            viewInputDosen.dispose();
            new ViewDataDosen();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    public void editDosen(int id) {
        try {
            ModelDosen dosenToEdit = new ModelDosen();
                       
            Integer id = viewEditDosen.getInputId();
            String name = viewEditDosen.getInputNama();
            String no_hp = viewEditDosen.getInputNumber();
            String email = viewEditDosen.getInputEmail();

            if ("".equals(id) || "".equals(name) || "".equals(no_hp) || "".equals(email)) {
                throw new Exception("Tidak boleh kosong!");
            }
            
            dosenToEdit.setId(id);
            dosenToEdit.setName(name);
            dosenToEdit.setNumber(no_hp);
            dosenToEdit.setEmail(email);
            
            daoDosenImpl.update(dosenToEdit);

            JOptionPane.showMessageDialog(null, "Data Dosen berhasil diupdate");

            viewEditDosen.dispose();
            new ViewDataDosen();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    public void deleteDosen(Integer row) {
        Integer id = (int) viewTableDosen.getTableDosen().getValueAt(row, 0);
        String name = viewTableDosen.getTableDosen().getValueAt(row, 1).toString();

        int input = JOptionPane.showConfirmDialog(
                null,
                "Delete " + name + "?",
                "Delete Dosen",
                JOptionPane.YES_NO_OPTION
        );

        if (input == 0) {
            daoDosenImpl.delete(id);

            JOptionPane.showMessageDialog(null, "Hapus Data berhasil");

            showAllDosen();
        }
    }
}
